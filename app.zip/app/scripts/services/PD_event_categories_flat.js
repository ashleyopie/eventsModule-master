if (typeof PlanetDiscoverCached === 'undefined') {
    PlanetDiscoverCached = {};
}

// Event Category Definitions (flat)
'use strict';

angular.module('eventsAppApp')
    .controller('MainCtrl', function($scope) {

    });
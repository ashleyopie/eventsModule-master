'use strict';

angular.module('eventsAppApp')
  .controller('AdvsearchCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
